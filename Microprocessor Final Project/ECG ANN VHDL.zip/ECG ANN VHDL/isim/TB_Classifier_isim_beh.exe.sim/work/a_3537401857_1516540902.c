/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_TEXTIO;
static const char *ng1 = "mif_file";
extern char *STD_STANDARD;
extern char *IEEE_P_2592010699;
static const char *ng4 = "D:/Fall 18/MicroProcessor/Projects/Microprocessor Final Project/ECG ANN VHDL/LUT_mif.vhd";
extern char *IEEE_P_1242562249;

int ieee_p_1242562249_sub_1657552908_1035706684(char *, char *, char *);
int ieee_p_1242562249_sub_2271993008_1035706684(char *, char *, char *);
char *ieee_p_1242562249_sub_3869231325_1035706684(char *, char *, char *, char *);
char *ieee_p_1242562249_sub_3991088854_1035706684(char *, char *, char *, char *);
char *ieee_p_2592010699_sub_393209765_503743352(char *, char *, char *, char *);


char *work_a_3537401857_1516540902_sub_784343493_2134189630(char *t1, char *t2, char *t3)
{
    char t4[328];
    char t5[24];
    char t20[16];
    char t32[32];
    char t40[8192];
    char t53[16];
    char *t0;
    char *t6;
    char *t7;
    unsigned int t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    int t18;
    unsigned int t19;
    int t21;
    char *t22;
    char *t23;
    int t24;
    unsigned int t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t33;
    char *t34;
    int t35;
    char *t36;
    int t37;
    char *t38;
    char *t39;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    unsigned char t47;
    char *t48;
    int t49;
    int t50;
    char *t51;
    char *t52;
    unsigned int t54;
    unsigned int t55;

LAB0:    t6 = ((STD_TEXTIO) + 3440);
    t7 = (t3 + 12U);
    t8 = *((unsigned int *)t7);
    t8 = (t8 * 1U);
    t9 = (t4 + 4U);
    t10 = xsi_create_file_variable_in_buffer(0, ng1, t6, t2, t8, 1);
    *((char **)t9) = t10;
    t11 = (t4 + 12U);
    t12 = ((STD_TEXTIO) + 3280);
    t13 = (t11 + 56U);
    *((char **)t13) = t12;
    t14 = (t11 + 40U);
    *((char **)t14) = 0;
    t15 = (t11 + 64U);
    *((int *)t15) = 1;
    t16 = (t11 + 48U);
    *((char **)t16) = 0;
    t17 = (9 - 2);
    t18 = (0 - t17);
    t19 = (t18 * -1);
    t19 = (t19 + 1);
    t19 = (t19 * 1U);
    t21 = (9 - 2);
    t22 = (t20 + 0U);
    t23 = (t22 + 0U);
    *((int *)t23) = t21;
    t23 = (t22 + 4U);
    *((int *)t23) = 0;
    t23 = (t22 + 8U);
    *((int *)t23) = -1;
    t24 = (0 - t21);
    t25 = (t24 * -1);
    t25 = (t25 + 1);
    t23 = (t22 + 12U);
    *((unsigned int *)t23) = t25;
    t23 = (t4 + 84U);
    t26 = ((STD_STANDARD) + 1112);
    t27 = (t23 + 88U);
    *((char **)t27) = t26;
    t28 = (char *)alloca(t19);
    t29 = (t23 + 56U);
    *((char **)t29) = t28;
    xsi_type_set_default_value(t26, t28, t20);
    t30 = (t23 + 64U);
    *((char **)t30) = t20;
    t31 = (t23 + 80U);
    *((unsigned int *)t31) = t19;
    t33 = (t32 + 0U);
    t34 = (t33 + 0U);
    *((int *)t34) = 0;
    t34 = (t33 + 4U);
    *((int *)t34) = 1023;
    t34 = (t33 + 8U);
    *((int *)t34) = 1;
    t35 = (1023 - 0);
    t25 = (t35 * 1);
    t25 = (t25 + 1);
    t34 = (t33 + 12U);
    *((unsigned int *)t34) = t25;
    t34 = (t32 + 16U);
    t36 = (t34 + 0U);
    *((int *)t36) = 7;
    t36 = (t34 + 4U);
    *((int *)t36) = 0;
    t36 = (t34 + 8U);
    *((int *)t36) = -1;
    t37 = (0 - 7);
    t25 = (t37 * -1);
    t25 = (t25 + 1);
    t36 = (t34 + 12U);
    *((unsigned int *)t36) = t25;
    t36 = (t4 + 204U);
    t38 = (t1 + 4216);
    t39 = (t36 + 88U);
    *((char **)t39) = t38;
    t41 = (t36 + 56U);
    *((char **)t41) = t40;
    xsi_type_set_default_value(t38, t40, 0);
    t42 = (t36 + 64U);
    t43 = (t38 + 80U);
    t44 = *((char **)t43);
    *((char **)t42) = t44;
    t45 = (t36 + 80U);
    *((unsigned int *)t45) = 8192U;
    t46 = (t5 + 4U);
    t47 = (t2 != 0);
    if (t47 == 1)
        goto LAB3;

LAB2:    t48 = (t5 + 12U);
    *((char **)t48) = t3;
    t49 = 0;
    t50 = 1023;

LAB4:    if (t49 <= t50)
        goto LAB5;

LAB7:    t6 = (t36 + 56U);
    t7 = *((char **)t6);
    t47 = (8192U != 8192U);
    if (t47 == 1)
        goto LAB9;

LAB10:    t0 = xsi_get_transient_memory(8192U);
    memcpy(t0, t7, 8192U);

LAB1:    xsi_access_variable_delete(t11);
    t6 = (t4 + 4U);
    t7 = *((char **)t6);
    xsi_delete_file_variable(t7);
    return t0;
LAB3:    *((char **)t46) = t2;
    goto LAB2;

LAB5:    t51 = (t4 + 4U);
    t52 = *((char **)t51);
    std_textio_readline(STD_TEXTIO, (char *)0, t52, t11);
    t6 = (t23 + 56U);
    t7 = *((char **)t6);
    std_textio_read4(STD_TEXTIO, (char *)0, t11, t7, t20);
    t6 = (t23 + 56U);
    t7 = *((char **)t6);
    t6 = ieee_p_2592010699_sub_393209765_503743352(IEEE_P_2592010699, t53, t7, t20);
    t9 = (t36 + 56U);
    t10 = *((char **)t9);
    t17 = (t49 - 0);
    t8 = (t17 * 1);
    xsi_vhdl_check_range_of_index(0, 1023, 1, t49);
    t18 = (9 - 2);
    t21 = (0 - t18);
    t19 = (t21 * -1);
    t19 = (t19 + 1);
    t19 = (t19 * 1U);
    t25 = (t19 * t8);
    t54 = (0 + t25);
    t9 = (t10 + t54);
    t12 = (t53 + 12U);
    t55 = *((unsigned int *)t12);
    t55 = (t55 * 1U);
    memcpy(t9, t6, t55);

LAB6:    if (t49 == t50)
        goto LAB7;

LAB8:    t17 = (t49 + 1);
    t49 = t17;
    goto LAB4;

LAB9:    xsi_size_not_matching(8192U, 8192U, 0);
    goto LAB10;

LAB11:;
}

static void work_a_3537401857_1516540902_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(81, ng4);

LAB3:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 3656);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 9U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 3560);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_3537401857_1516540902_p_1(char *t0)
{
    char t18[16];
    char t20[16];
    char t30[16];
    char t32[16];
    char *t1;
    char *t2;
    int t3;
    unsigned char t4;
    char *t5;
    char *t6;
    int t7;
    unsigned int t8;
    int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    int t13;
    int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;
    char *t19;
    char *t21;
    char *t22;
    int t23;
    unsigned int t24;
    unsigned char t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    unsigned int t31;
    unsigned int t33;
    unsigned int t34;
    unsigned char t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;

LAB0:    xsi_set_current_line(85, ng4);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6432U);
    t3 = ieee_p_1242562249_sub_2271993008_1035706684(IEEE_P_1242562249, t2, t1);
    t4 = (t3 > 1023);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6432U);
    t3 = ieee_p_1242562249_sub_2271993008_1035706684(IEEE_P_1242562249, t2, t1);
    t7 = (-(1023));
    t4 = (t3 < t7);
    if (t4 != 0)
        goto LAB10;

LAB11:    xsi_set_current_line(90, ng4);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (31 - 31);
    t8 = (t3 * -1);
    t10 = (1U * t8);
    t11 = (0 + t10);
    t1 = (t2 + t11);
    t4 = *((unsigned char *)t1);
    t25 = (t4 == (unsigned char)3);
    if (t25 != 0)
        goto LAB15;

LAB17:    xsi_set_current_line(93, ng4);
    t1 = (t0 + 2008U);
    t2 = *((char **)t1);
    t1 = (t0 + 1032U);
    t5 = *((char **)t1);
    t1 = (t0 + 6432U);
    t3 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t5, t1);
    t7 = (t3 - 0);
    t8 = (t7 * 1);
    xsi_vhdl_check_range_of_index(0, 1023, 1, t3);
    t10 = (8U * t8);
    t11 = (0 + t10);
    t6 = (t2 + t11);
    t17 = ((IEEE_P_1242562249) + 3112);
    t19 = (t20 + 0U);
    t21 = (t19 + 0U);
    *((int *)t21) = 7;
    t21 = (t19 + 4U);
    *((int *)t21) = 0;
    t21 = (t19 + 8U);
    *((int *)t21) = -1;
    t9 = (0 - 7);
    t15 = (t9 * -1);
    t15 = (t15 + 1);
    t21 = (t19 + 12U);
    *((unsigned int *)t21) = t15;
    t12 = xsi_base_array_concat(t12, t18, t17, (char)99, (unsigned char)2, (char)97, t6, t20, (char)101);
    t15 = (1U + 8U);
    t4 = (9U != t15);
    if (t4 == 1)
        goto LAB20;

LAB21:    t21 = (t0 + 3720);
    t22 = (t21 + 56U);
    t26 = *((char **)t22);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memcpy(t28, t12, 9U);
    xsi_driver_first_trans_fast(t21);

LAB16:
LAB3:    t1 = (t0 + 3576);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(86, ng4);
    t5 = xsi_get_transient_memory(8U);
    memset(t5, 0, 8U);
    t6 = t5;
    t7 = (9 - 2);
    if (-1 == 1)
        goto LAB5;

LAB6:    t8 = 0;

LAB7:    t9 = (t8 - 0);
    t10 = (t9 * 1);
    t11 = (1U * t10);
    t12 = (t6 + t11);
    t13 = (9 - 2);
    t14 = (0 - t13);
    t15 = (t14 * -1);
    t15 = (t15 + 1);
    t16 = (1U * t15);
    memset(t12, (unsigned char)2, t16);
    t19 = ((IEEE_P_1242562249) + 3112);
    t21 = (t20 + 0U);
    t22 = (t21 + 0U);
    *((int *)t22) = 0;
    t22 = (t21 + 4U);
    *((int *)t22) = 7;
    t22 = (t21 + 8U);
    *((int *)t22) = 1;
    t23 = (7 - 0);
    t24 = (t23 * 1);
    t24 = (t24 + 1);
    t22 = (t21 + 12U);
    *((unsigned int *)t22) = t24;
    t17 = xsi_base_array_concat(t17, t18, t19, (char)99, (unsigned char)3, (char)97, t5, t20, (char)101);
    t24 = (1U + 8U);
    t25 = (9U != t24);
    if (t25 == 1)
        goto LAB8;

LAB9:    t22 = (t0 + 3720);
    t26 = (t22 + 56U);
    t27 = *((char **)t26);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    memcpy(t29, t17, 9U);
    xsi_driver_first_trans_fast(t22);
    goto LAB3;

LAB5:    t8 = t7;
    goto LAB7;

LAB8:    xsi_size_not_matching(9U, t24, 0);
    goto LAB9;

LAB10:    xsi_set_current_line(88, ng4);
    t5 = xsi_get_transient_memory(9U);
    memset(t5, 0, 9U);
    t6 = t5;
    t9 = (9 - 1);
    if (-1 == -1)
        goto LAB12;

LAB13:    t8 = 0;

LAB14:    t13 = (t8 - 8);
    t10 = (t13 * -1);
    t11 = (1U * t10);
    t12 = (t6 + t11);
    t14 = (9 - 1);
    t23 = (0 - t14);
    t15 = (t23 * -1);
    t15 = (t15 + 1);
    t16 = (1U * t15);
    memset(t12, (unsigned char)2, t16);
    t17 = (t0 + 3720);
    t19 = (t17 + 56U);
    t21 = *((char **)t19);
    t22 = (t21 + 56U);
    t26 = *((char **)t22);
    memcpy(t26, t5, 9U);
    xsi_driver_first_trans_fast(t17);
    goto LAB3;

LAB12:    t8 = t9;
    goto LAB14;

LAB15:    xsi_set_current_line(91, ng4);
    t5 = (t0 + 2008U);
    t6 = *((char **)t5);
    t5 = (t0 + 1032U);
    t12 = *((char **)t5);
    t5 = (t0 + 6432U);
    t17 = ieee_p_1242562249_sub_3869231325_1035706684(IEEE_P_1242562249, t20, t12, t5);
    t7 = ieee_p_1242562249_sub_2271993008_1035706684(IEEE_P_1242562249, t17, t20);
    t9 = (t7 - 0);
    t15 = (t9 * 1);
    xsi_vhdl_check_range_of_index(0, 1023, 1, t7);
    t16 = (8U * t15);
    t24 = (0 + t16);
    t19 = (t6 + t24);
    t21 = (t30 + 0U);
    t22 = (t21 + 0U);
    *((int *)t22) = 7;
    t22 = (t21 + 4U);
    *((int *)t22) = 0;
    t22 = (t21 + 8U);
    *((int *)t22) = -1;
    t13 = (0 - 7);
    t31 = (t13 * -1);
    t31 = (t31 + 1);
    t22 = (t21 + 12U);
    *((unsigned int *)t22) = t31;
    t22 = ieee_p_1242562249_sub_3991088854_1035706684(IEEE_P_1242562249, t18, t19, t30);
    t27 = ((IEEE_P_1242562249) + 3112);
    t26 = xsi_base_array_concat(t26, t32, t27, (char)99, (unsigned char)2, (char)97, t22, t18, (char)101);
    t28 = (t18 + 12U);
    t31 = *((unsigned int *)t28);
    t33 = (1U * t31);
    t34 = (1U + t33);
    t35 = (9U != t34);
    if (t35 == 1)
        goto LAB18;

LAB19:    t29 = (t0 + 3720);
    t36 = (t29 + 56U);
    t37 = *((char **)t36);
    t38 = (t37 + 56U);
    t39 = *((char **)t38);
    memcpy(t39, t26, 9U);
    xsi_driver_first_trans_fast(t29);
    goto LAB16;

LAB18:    xsi_size_not_matching(9U, t34, 0);
    goto LAB19;

LAB20:    xsi_size_not_matching(9U, t15, 0);
    goto LAB21;

}


extern void work_a_3537401857_1516540902_init()
{
	static char *pe[] = {(void *)work_a_3537401857_1516540902_p_0,(void *)work_a_3537401857_1516540902_p_1};
	static char *se[] = {(void *)work_a_3537401857_1516540902_sub_784343493_2134189630};
	xsi_register_didat("work_a_3537401857_1516540902", "isim/TB_Classifier_isim_beh.exe.sim/work/a_3537401857_1516540902.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
