/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *XILINXCORELIB_P_1521474790;
char *WORK_P_3785195435;
char *IEEE_P_2592010699;
char *XILINXCORELIB_P_3155556343;
char *IEEE_P_1242562249;
char *WORK_P_4100144650;
char *XILINXCORELIB_P_1837083571;
char *STD_STANDARD;
char *WORK_P_2381739659;
char *IEEE_P_0774719531;
char *STD_TEXTIO;
char *IEEE_P_3620187407;
char *XILINXCORELIB_P_3381355550;
char *IEEE_P_3499444699;
char *XILINXCORELIB_P_3743709326;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    ieee_p_1242562249_init();
    work_p_2381739659_init();
    work_p_3785195435_init();
    work_p_4100144650_init();
    std_textio_init();
    ieee_p_3499444699_init();
    ieee_p_3620187407_init();
    work_a_0081327778_3212880686_init();
    ieee_p_0774719531_init();
    xilinxcorelib_p_1837083571_init();
    xilinxcorelib_p_3381355550_init();
    xilinxcorelib_p_3155556343_init();
    xilinxcorelib_p_1521474790_init();
    xilinxcorelib_p_3743709326_init();
    xilinxcorelib_a_1259152764_3212880686_init();
    xilinxcorelib_a_2499546595_3212880686_init();
    xilinxcorelib_a_3985260382_3212880686_init();
    xilinxcorelib_a_0846927809_3212880686_init();
    xilinxcorelib_a_1985319161_3212880686_init();
    xilinxcorelib_a_2846144614_3212880686_init();
    xilinxcorelib_a_3725427157_3212880686_init();
    xilinxcorelib_a_0033335626_3212880686_init();
    xilinxcorelib_a_2436217400_3212880686_init();
    xilinxcorelib_a_1321505447_3212880686_init();
    xilinxcorelib_a_1887821352_3212880686_init();
    xilinxcorelib_a_2943678135_3212880686_init();
    xilinxcorelib_a_2493194524_3212880686_init();
    xilinxcorelib_a_1896190570_3212880686_init();
    xilinxcorelib_a_1124229283_3212880686_init();
    xilinxcorelib_a_2633189436_3212880686_init();
    xilinxcorelib_a_2702707078_3212880686_init();
    work_a_2580980218_2428546697_init();
    work_a_3703939451_1114034775_init();
    work_a_0149894508_3212880686_init();
    work_a_2895730147_3212880686_init();
    work_a_1536786107_3212880686_init();
    work_a_0295612575_3212880686_init();
    work_a_3431781255_3212880686_init();
    work_a_3537401857_1516540902_init();
    work_a_2225201626_3212880686_init();
    work_a_2951565247_3212880686_init();
    work_a_1048839931_3212880686_init();
    work_a_1438815495_3212880686_init();
    work_a_0535162972_3212880686_init();
    work_a_2324392432_3212880686_init();
    work_a_1955241509_3212880686_init();
    work_a_1273550243_3212880686_init();
    work_a_0036270906_3212880686_init();
    work_a_1271815375_3212880686_init();
    work_a_3696762242_3212880686_init();
    work_a_0257751740_3212880686_init();
    work_a_3267669764_3212880686_init();
    work_a_1111616105_3212880686_init();
    work_a_2683404259_3212880686_init();
    work_a_2835254500_3212880686_init();
    work_a_3042359192_2372691052_init();


    xsi_register_tops("work_a_3042359192_2372691052");

    XILINXCORELIB_P_1521474790 = xsi_get_engine_memory("xilinxcorelib_p_1521474790");
    WORK_P_3785195435 = xsi_get_engine_memory("work_p_3785195435");
    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);
    XILINXCORELIB_P_3155556343 = xsi_get_engine_memory("xilinxcorelib_p_3155556343");
    IEEE_P_1242562249 = xsi_get_engine_memory("ieee_p_1242562249");
    WORK_P_4100144650 = xsi_get_engine_memory("work_p_4100144650");
    XILINXCORELIB_P_1837083571 = xsi_get_engine_memory("xilinxcorelib_p_1837083571");
    STD_STANDARD = xsi_get_engine_memory("std_standard");
    WORK_P_2381739659 = xsi_get_engine_memory("work_p_2381739659");
    IEEE_P_0774719531 = xsi_get_engine_memory("ieee_p_0774719531");
    STD_TEXTIO = xsi_get_engine_memory("std_textio");
    IEEE_P_3620187407 = xsi_get_engine_memory("ieee_p_3620187407");
    XILINXCORELIB_P_3381355550 = xsi_get_engine_memory("xilinxcorelib_p_3381355550");
    IEEE_P_3499444699 = xsi_get_engine_memory("ieee_p_3499444699");
    XILINXCORELIB_P_3743709326 = xsi_get_engine_memory("xilinxcorelib_p_3743709326");

    return xsi_run_simulation(argc, argv);

}
