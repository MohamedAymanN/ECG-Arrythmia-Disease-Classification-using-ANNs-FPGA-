/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Fall 18/MicroProcessor/Projects/Microprocessor Final Project/ECG ANN VHDL/MUX_2x1.vhd";



static void work_a_1955241509_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    char *t19;
    int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;

LAB0:    xsi_set_current_line(42, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB3;

LAB4:    t15 = (t0 + 1192U);
    t16 = *((char **)t15);
    t17 = *((unsigned char *)t16);
    t18 = (t17 == (unsigned char)3);
    if (t18 != 0)
        goto LAB5;

LAB6:
LAB2:    t29 = (t0 + 2832);
    *((int *)t29) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 1032U);
    t5 = *((char **)t1);
    t6 = (0 - 0);
    t7 = (t6 * 1);
    t8 = (32U * t7);
    t9 = (0 + t8);
    t1 = (t5 + t9);
    t10 = (t0 + 2912);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    memcpy(t14, t1, 32U);
    xsi_driver_first_trans_fast_port(t10);
    goto LAB2;

LAB5:    t15 = (t0 + 1032U);
    t19 = *((char **)t15);
    t20 = (1 - 0);
    t21 = (t20 * 1);
    t22 = (32U * t21);
    t23 = (0 + t22);
    t15 = (t19 + t23);
    t24 = (t0 + 2912);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memcpy(t28, t15, 32U);
    xsi_driver_first_trans_fast_port(t24);
    goto LAB2;

}


extern void work_a_1955241509_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1955241509_3212880686_p_0};
	xsi_register_didat("work_a_1955241509_3212880686", "isim/TB_Classifier_isim_beh.exe.sim/work/a_1955241509_3212880686.didat");
	xsi_register_executes(pe);
}
