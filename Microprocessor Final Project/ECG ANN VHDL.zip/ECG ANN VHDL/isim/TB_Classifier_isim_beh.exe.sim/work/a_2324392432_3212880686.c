/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Fall 18/MicroProcessor/Projects/Microprocessor Final Project/ECG ANN VHDL/MAC_Out.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );
unsigned char ieee_p_2592010699_sub_2545490612_503743352(char *, unsigned char , unsigned char );
char *ieee_p_2592010699_sub_795620321_503743352(char *, char *, char *, char *, char *, char *);


static void work_a_2324392432_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(85, ng0);

LAB3:    t1 = (t0 + 3272U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 6896);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 6720);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2324392432_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    char *t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned char t30;
    unsigned char t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;

LAB0:    xsi_set_current_line(88, ng0);

LAB3:    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t3 = (0 - 3);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 1832U);
    t9 = *((char **)t8);
    t10 = (1 - 3);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 1832U);
    t17 = *((char **)t16);
    t18 = (2 - 3);
    t19 = (t18 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t16 = (t17 + t21);
    t22 = *((unsigned char *)t16);
    t23 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t15, t22);
    t24 = (t0 + 1832U);
    t25 = *((char **)t24);
    t26 = (3 - 3);
    t27 = (t26 * -1);
    t28 = (1U * t27);
    t29 = (0 + t28);
    t24 = (t25 + t29);
    t30 = *((unsigned char *)t24);
    t31 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t23, t30);
    t32 = (t0 + 6960);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = (t34 + 56U);
    t36 = *((char **)t35);
    *((unsigned char *)t36) = t31;
    xsi_driver_first_trans_fast(t32);

LAB2:    t37 = (t0 + 6736);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2324392432_3212880686_p_2(char *t0)
{
    char t1[16];
    char t7[16];
    char t23[16];
    char *t2;
    char *t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned char t15;
    unsigned char t16;
    int t17;
    unsigned int t18;
    unsigned int t19;
    int t20;
    unsigned int t21;
    unsigned int t22;
    char *t24;
    char *t25;
    int t26;
    unsigned int t27;
    char *t28;
    unsigned int t29;
    unsigned char t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;

LAB0:    xsi_set_current_line(90, ng0);

LAB3:    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t4 = (31 - 24);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t2 = (t3 + t6);
    t8 = (t7 + 0U);
    t9 = (t8 + 0U);
    *((int *)t9) = 24;
    t9 = (t8 + 4U);
    *((int *)t9) = 0;
    t9 = (t8 + 8U);
    *((int *)t9) = -1;
    t10 = (0 - 24);
    t11 = (t10 * -1);
    t11 = (t11 + 1);
    t9 = (t8 + 12U);
    *((unsigned int *)t9) = t11;
    t9 = xsi_get_transient_memory(25U);
    memset(t9, 0, 25U);
    t12 = t9;
    t13 = (t0 + 3272U);
    t14 = *((char **)t13);
    t15 = *((unsigned char *)t14);
    t16 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t15);
    if (-1 == -1)
        goto LAB5;

LAB6:    t11 = 0;

LAB7:    t17 = (t11 - 24);
    t18 = (t17 * -1);
    t19 = (1U * t18);
    t13 = (t12 + t19);
    t20 = (0 - 24);
    t21 = (t20 * -1);
    t21 = (t21 + 1);
    t22 = (1U * t21);
    memset(t13, t16, t22);
    t24 = (t23 + 0U);
    t25 = (t24 + 0U);
    *((int *)t25) = 0;
    t25 = (t24 + 4U);
    *((int *)t25) = 24;
    t25 = (t24 + 8U);
    *((int *)t25) = 1;
    t26 = (24 - 0);
    t27 = (t26 * 1);
    t27 = (t27 + 1);
    t25 = (t24 + 12U);
    *((unsigned int *)t25) = t27;
    t25 = ieee_p_2592010699_sub_795620321_503743352(IEEE_P_2592010699, t1, t2, t7, t9, t23);
    t28 = (t1 + 12U);
    t27 = *((unsigned int *)t28);
    t29 = (1U * t27);
    t30 = (25U != t29);
    if (t30 == 1)
        goto LAB8;

LAB9:    t31 = (t0 + 7024);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    t34 = (t33 + 56U);
    t35 = *((char **)t34);
    memcpy(t35, t25, 25U);
    xsi_driver_first_trans_fast(t31);

LAB2:    t36 = (t0 + 6752);
    *((int *)t36) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    t11 = 24;
    goto LAB7;

LAB8:    xsi_size_not_matching(25U, t29, 0);
    goto LAB9;

}

static void work_a_2324392432_3212880686_p_3(char *t0)
{
    char t1[16];
    char t7[16];
    char t23[16];
    char *t2;
    char *t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned char t15;
    unsigned char t16;
    int t17;
    unsigned int t18;
    unsigned int t19;
    int t20;
    unsigned int t21;
    unsigned int t22;
    char *t24;
    char *t25;
    int t26;
    unsigned int t27;
    char *t28;
    unsigned int t29;
    unsigned char t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;

LAB0:    xsi_set_current_line(91, ng0);

LAB3:    t2 = (t0 + 1512U);
    t3 = *((char **)t2);
    t4 = (31 - 17);
    t5 = (t4 * 1U);
    t6 = (0 + t5);
    t2 = (t3 + t6);
    t8 = (t7 + 0U);
    t9 = (t8 + 0U);
    *((int *)t9) = 17;
    t9 = (t8 + 4U);
    *((int *)t9) = 0;
    t9 = (t8 + 8U);
    *((int *)t9) = -1;
    t10 = (0 - 17);
    t11 = (t10 * -1);
    t11 = (t11 + 1);
    t9 = (t8 + 12U);
    *((unsigned int *)t9) = t11;
    t9 = xsi_get_transient_memory(18U);
    memset(t9, 0, 18U);
    t12 = t9;
    t13 = (t0 + 3272U);
    t14 = *((char **)t13);
    t15 = *((unsigned char *)t14);
    t16 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t15);
    if (-1 == -1)
        goto LAB5;

LAB6:    t11 = 0;

LAB7:    t17 = (t11 - 17);
    t18 = (t17 * -1);
    t19 = (1U * t18);
    t13 = (t12 + t19);
    t20 = (0 - 17);
    t21 = (t20 * -1);
    t21 = (t21 + 1);
    t22 = (1U * t21);
    memset(t13, t16, t22);
    t24 = (t23 + 0U);
    t25 = (t24 + 0U);
    *((int *)t25) = 0;
    t25 = (t24 + 4U);
    *((int *)t25) = 17;
    t25 = (t24 + 8U);
    *((int *)t25) = 1;
    t26 = (17 - 0);
    t27 = (t26 * 1);
    t27 = (t27 + 1);
    t25 = (t24 + 12U);
    *((unsigned int *)t25) = t27;
    t25 = ieee_p_2592010699_sub_795620321_503743352(IEEE_P_2592010699, t1, t2, t7, t9, t23);
    t28 = (t1 + 12U);
    t27 = *((unsigned int *)t28);
    t29 = (1U * t27);
    t30 = (18U != t29);
    if (t30 == 1)
        goto LAB8;

LAB9:    t31 = (t0 + 7088);
    t32 = (t31 + 56U);
    t33 = *((char **)t32);
    t34 = (t33 + 56U);
    t35 = *((char **)t34);
    memcpy(t35, t25, 18U);
    xsi_driver_first_trans_fast(t31);

LAB2:    t36 = (t0 + 6768);
    *((int *)t36) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    t11 = 17;
    goto LAB7;

LAB8:    xsi_size_not_matching(18U, t29, 0);
    goto LAB9;

}

static void work_a_2324392432_3212880686_p_4(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    char *t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned char t30;
    unsigned char t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;

LAB0:    xsi_set_current_line(100, ng0);

LAB3:    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t3 = (0 - 3);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 1832U);
    t9 = *((char **)t8);
    t10 = (1 - 3);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 1832U);
    t17 = *((char **)t16);
    t18 = (2 - 3);
    t19 = (t18 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t16 = (t17 + t21);
    t22 = *((unsigned char *)t16);
    t23 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t15, t22);
    t24 = (t0 + 1832U);
    t25 = *((char **)t24);
    t26 = (3 - 3);
    t27 = (t26 * -1);
    t28 = (1U * t27);
    t29 = (0 + t28);
    t24 = (t25 + t29);
    t30 = *((unsigned char *)t24);
    t31 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t23, t30);
    t32 = (t0 + 7152);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = (t34 + 56U);
    t36 = *((char **)t35);
    *((unsigned char *)t36) = t31;
    xsi_driver_first_trans_fast(t32);

LAB2:    t37 = (t0 + 6784);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2324392432_3212880686_p_5(char *t0)
{
    char t32[16];
    char t34[16];
    char t42[16];
    char t44[16];
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned char t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned char t21;
    unsigned int t22;
    int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;
    char *t33;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    char *t39;
    char *t41;
    char *t43;
    char *t45;
    char *t46;
    int t47;
    unsigned int t48;
    unsigned char t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;

LAB0:    xsi_set_current_line(102, ng0);
    t1 = (t0 + 3112U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB3;

LAB4:    t10 = (t0 + 3112U);
    t11 = *((char **)t10);
    t12 = *((unsigned char *)t11);
    t13 = (t12 == (unsigned char)2);
    if (t13 != 0)
        goto LAB5;

LAB6:
LAB2:    t54 = (t0 + 6800);
    *((int *)t54) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 2632U);
    t5 = *((char **)t1);
    t1 = (t0 + 7216);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 48U);
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB5:    t10 = xsi_get_transient_memory(8U);
    memset(t10, 0, 8U);
    t14 = t10;
    t15 = (t0 + 1672U);
    t16 = *((char **)t15);
    t17 = (31 - 31);
    t18 = (t17 * -1);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t15 = (t16 + t20);
    t21 = *((unsigned char *)t15);
    if (-1 == 1)
        goto LAB7;

LAB8:    t22 = 0;

LAB9:    t23 = (t22 - 0);
    t24 = (t23 * 1);
    t25 = (1U * t24);
    t26 = (t14 + t25);
    t27 = (0 - 7);
    t28 = (t27 * -1);
    t28 = (t28 + 1);
    t29 = (1U * t28);
    memset(t26, t21, t29);
    t30 = (t0 + 1672U);
    t31 = *((char **)t30);
    t33 = ((IEEE_P_2592010699) + 4024);
    t35 = (t34 + 0U);
    t36 = (t35 + 0U);
    *((int *)t36) = 0;
    t36 = (t35 + 4U);
    *((int *)t36) = 7;
    t36 = (t35 + 8U);
    *((int *)t36) = 1;
    t37 = (7 - 0);
    t38 = (t37 * 1);
    t38 = (t38 + 1);
    t36 = (t35 + 12U);
    *((unsigned int *)t36) = t38;
    t36 = (t0 + 11728U);
    t30 = xsi_base_array_concat(t30, t32, t33, (char)97, t10, t34, (char)97, t31, t36, (char)101);
    t39 = (t0 + 12126);
    t43 = ((IEEE_P_2592010699) + 4024);
    t45 = (t44 + 0U);
    t46 = (t45 + 0U);
    *((int *)t46) = 0;
    t46 = (t45 + 4U);
    *((int *)t46) = 7;
    t46 = (t45 + 8U);
    *((int *)t46) = 1;
    t47 = (7 - 0);
    t38 = (t47 * 1);
    t38 = (t38 + 1);
    t46 = (t45 + 12U);
    *((unsigned int *)t46) = t38;
    t41 = xsi_base_array_concat(t41, t42, t43, (char)97, t30, t32, (char)97, t39, t44, (char)101);
    t38 = (8U + 32U);
    t48 = (t38 + 8U);
    t49 = (48U != t48);
    if (t49 == 1)
        goto LAB10;

LAB11:    t46 = (t0 + 7216);
    t50 = (t46 + 56U);
    t51 = *((char **)t50);
    t52 = (t51 + 56U);
    t53 = *((char **)t52);
    memcpy(t53, t41, 48U);
    xsi_driver_first_trans_fast(t46);
    goto LAB2;

LAB7:    t22 = 7;
    goto LAB9;

LAB10:    xsi_size_not_matching(48U, t48, 0);
    goto LAB11;

}

static void work_a_2324392432_3212880686_p_6(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(105, ng0);

LAB3:    t1 = (t0 + 2792U);
    t2 = *((char **)t1);
    t3 = (47 - 39);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 7280);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 32U);
    xsi_driver_first_trans_fast_port(t6);

LAB2:    t11 = (t0 + 6816);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_2324392432_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2324392432_3212880686_p_0,(void *)work_a_2324392432_3212880686_p_1,(void *)work_a_2324392432_3212880686_p_2,(void *)work_a_2324392432_3212880686_p_3,(void *)work_a_2324392432_3212880686_p_4,(void *)work_a_2324392432_3212880686_p_5,(void *)work_a_2324392432_3212880686_p_6};
	xsi_register_didat("work_a_2324392432_3212880686", "isim/TB_Classifier_isim_beh.exe.sim/work/a_2324392432_3212880686.didat");
	xsi_register_executes(pe);
}
