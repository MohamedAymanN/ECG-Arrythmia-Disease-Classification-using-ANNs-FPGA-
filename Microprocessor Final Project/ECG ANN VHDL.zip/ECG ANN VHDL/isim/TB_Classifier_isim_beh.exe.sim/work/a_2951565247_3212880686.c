/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Fall 18/MicroProcessor/Projects/Microprocessor Final Project/ECG ANN VHDL/HiddenLayer.vhd";
extern char *IEEE_P_1242562249;



static void work_a_2951565247_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(91, ng0);

LAB3:    t1 = (t0 + 6592U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 10960);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 10848);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_2951565247_3212880686_p_1(char *t0)
{
    char t13[16];
    char t15[16];
    char *t1;
    char *t2;
    unsigned int t3;
    int t4;
    unsigned int t5;
    unsigned int t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t14;
    char *t16;
    char *t17;
    int t18;
    unsigned int t19;
    unsigned char t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;

LAB0:    xsi_set_current_line(92, ng0);

LAB3:    t1 = xsi_get_transient_memory(23U);
    memset(t1, 0, 23U);
    t2 = t1;
    if (-1 == 1)
        goto LAB5;

LAB6:    t3 = 0;

LAB7:    t4 = (t3 - 0);
    t5 = (t4 * 1);
    t6 = (1U * t5);
    t7 = (t2 + t6);
    t8 = (0 - 22);
    t9 = (t8 * -1);
    t9 = (t9 + 1);
    t10 = (1U * t9);
    memset(t7, (unsigned char)2, t10);
    t11 = (t0 + 6912U);
    t12 = *((char **)t11);
    t14 = ((IEEE_P_1242562249) + 3112);
    t16 = (t15 + 0U);
    t17 = (t16 + 0U);
    *((int *)t17) = 0;
    t17 = (t16 + 4U);
    *((int *)t17) = 22;
    t17 = (t16 + 8U);
    *((int *)t17) = 1;
    t18 = (22 - 0);
    t19 = (t18 * 1);
    t19 = (t19 + 1);
    t17 = (t16 + 12U);
    *((unsigned int *)t17) = t19;
    t17 = (t0 + 20708U);
    t11 = xsi_base_array_concat(t11, t13, t14, (char)97, t1, t15, (char)97, t12, t17, (char)101);
    t19 = (23U + 9U);
    t20 = (32U != t19);
    if (t20 == 1)
        goto LAB8;

LAB9:    t21 = (t0 + 11024);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t11, 32U);
    xsi_driver_first_trans_fast_port(t21);

LAB2:    t26 = (t0 + 10864);
    *((int *)t26) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    t3 = 22;
    goto LAB7;

LAB8:    xsi_size_not_matching(32U, t19, 0);
    goto LAB9;

}

static void work_a_2951565247_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(131, ng0);

LAB3:    t1 = (t0 + 6752U);
    t2 = *((char **)t1);
    t1 = (t0 + 11088);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 10880);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_2951565247_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2951565247_3212880686_p_0,(void *)work_a_2951565247_3212880686_p_1,(void *)work_a_2951565247_3212880686_p_2};
	xsi_register_didat("work_a_2951565247_3212880686", "isim/TB_Classifier_isim_beh.exe.sim/work/a_2951565247_3212880686.didat");
	xsi_register_executes(pe);
}
